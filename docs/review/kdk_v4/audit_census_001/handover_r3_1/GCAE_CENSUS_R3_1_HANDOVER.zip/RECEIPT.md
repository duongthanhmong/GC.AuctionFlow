# GCAE Census R1+R2+R3+R3.1 — internal handover receipt

AUDITED_SOURCE_HEAD: 43d458f
R2_DELIVERABLE_COMMIT: e373486
R3_DELIVERABLE_COMMIT: e751f6e
R3.1_DELIVERABLE_COMMIT: recorded in external .sha256 + post-commit receipt

Payload files: 45.
Verify: unzip, then `sha256sum -c SHA256SUMS.txt` -> 45/45 OK.
SHA256SUMS.txt hashes every payload EXCEPT itself. 13_MANIFEST.md does not hash itself.
Historical KDK_D2_CONTRACT_FIT_001.md is included under its correct unsuffixed name, bannered SUPERSEDED(R3).
