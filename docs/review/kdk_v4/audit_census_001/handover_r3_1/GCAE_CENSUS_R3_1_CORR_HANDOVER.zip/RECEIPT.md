# GCAE Census R3.1-CORRECTION — internal receipt

AUDITED_SOURCE_HEAD: 43d458f
R3_DELIVERABLE_COMMIT: e751f6e
R3.1_DELIVERABLE_COMMIT: 6ef076896a0996adaef330499e4d78218e9e8d7c
R3.1-CORRECTION_COMMIT: in external .sha256 + POST_COMMIT_RECEIPT_CORR.md

Payload files: 46.
Verify: unzip, `sha256sum -c SHA256SUMS.txt` -> 46/46 OK.
Supersedes GCAE_CENSUS_R3_1_HANDOVER.zip (14d7cbbf, stale contract_compat_report.json).
SHA256SUMS.txt does not hash itself; 13_MANIFEST.md does not hash itself.
