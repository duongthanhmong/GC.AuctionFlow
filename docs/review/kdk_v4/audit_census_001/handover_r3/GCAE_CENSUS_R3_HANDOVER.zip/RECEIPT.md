# GCAE Census R1+R2+R3 — self-contained handover receipt

Commit: e373486 (R2 deliverable) + this R3 commit.
AUDITED_SOURCE_HEAD: 43d458f.

Verify: unzip, then `sha256sum -c SHA256SUMS.txt` -> expect 40/40 OK.
SHA256SUMS.txt hashes every payload file EXCEPT itself (no self-hash).
13_MANIFEST.md does NOT hash itself.

Payload files: 40.
