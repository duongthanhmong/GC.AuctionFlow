# GCAE Stage 2 Closure - independent verification

Unzip anywhere. This archive reproduces the exact repository sub-tree the test suite reads,
so no clone is required to check the result.

## Run the tests

```
python docs/review/kdk_v4/wp_l1_rithmic/stage2_closure/tests/test_stage2_closure.py
```

Expected final line: `RESULT: PASS - 47/47 checks`

## Reproduce the full transcript

```
python docs/review/kdk_v4/wp_l1_rithmic/stage2_closure/verification/run_verification.py
```

This re-hashes every artifact, recounts every figure from the files rather than the prose,
and re-resolves all 15 EvidenceIds. Expected final line: `RESULT: ALL CONFIRMED`.
(The git-state section will differ - there is no .git directory inside this archive.)

## Requirements

Python 3.11+, `jsonschema` and `referencing`:

```
pip install jsonschema referencing
```

Verified against Python 3.11.9, jsonschema 4.26.0, referencing 0.37.0.

## Git history

`GCAE_STAGE2_CLOSURE_full.bundle` is a self-contained bundle of branch
`wp-l1-rithmic-data-surface-discovery`, including commits `34f204c` and `8160f2c`. It
requires no external ref:

```
git clone GCAE_STAGE2_CLOSURE_full.bundle -b wp-l1-rithmic-data-surface-discovery gcae-check
```

The branch is also pushed to `origin`.

**On Windows, clone into a SHORT path** (e.g. `C:\gcae-check`). The repository contains
paths long enough to hit the 260-character `MAX_PATH` limit when cloned into an already-deep
directory - this was reproduced, and it fails with
`error: unable to create file ...: Filename too long` followed by
`fatal: unable to checkout working tree`. The commits clone correctly; only the working-tree
checkout fails. If a deep path is unavoidable:

```
git config --global core.longpaths true
```

The ADR filenames in this package were shortened for the same reason; the longest path in
the package is now 88 characters.

## What is in here

| path | what |
|---|---|
| `.../stage2_closure/` | the full package - 7 ADRs, 6 schemas, manifest, index, specs, tests |
| `.../wp_l1_rithmic/probe/` | the evidence artifacts every EvidenceId resolves to |
| `.../wp_l1_rithmic/12_*.md`, `13_*.md` | the probe reports the evidence came from |
| `.../mrbs_param_recon_r3/...REGISTRY_R3.csv` | the 134-parameter canonical registry |
| `SHA256SUMS.txt` | every file above, hashed |

## Status of the contents

All seven ADRs are `AWAITING_OWNER_APPROVAL` and are **not in force**. SC-005..009 in the
conflict register are **unresolved** by design - MRBS v1.1 line 62 forbids picking a side
without a decision record. Stage 2 is **not** declared accepted.
